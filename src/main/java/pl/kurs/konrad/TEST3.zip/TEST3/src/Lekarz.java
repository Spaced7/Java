import java.time.LocalDate;
import java.util.*;

public class Lekarz {
    private int identyfikator;
    private String nazwisko;
    private String imie;
    private String specjalnosc;
    private LocalDate dataUrodzenia;
    private String nip;
    private String pesel;
    private List<Wizyta> wizyty = new ArrayList<>();

    public Lekarz(int identyfikator, String nazwisko, String imie, String specjalnosc, LocalDate dataUrodzenia, String nip, String pesel) {
        this.identyfikator = identyfikator;
        this.nazwisko = nazwisko;
        this.imie = imie;
        this.specjalnosc = specjalnosc;
        this.dataUrodzenia = dataUrodzenia;
        this.nip = nip;
        this.pesel = pesel;
    }


    public static List<Lekarz> znajdzLekarzyZNajwiekszaLiczbaWizyt(List<Lekarz> lekarze) {
        List<Lekarz> lekarzeZNajwiecejWizyt = new ArrayList<>();
        int maxLiczbaWizyt = znajdzMaxLiczbaWizyt(lekarze);
        dodajLekarzyZNajwiekszaLiczbaWizyt(lekarze, lekarzeZNajwiecejWizyt, maxLiczbaWizyt);
        return lekarzeZNajwiecejWizyt;
    }


    public static List<String> znajdzNajpopularniejszeSpecjalizacje(List<Lekarz> lekarze) {
        Map<String, Integer> specjalizacjeLiczniki = obliczSpecjalizacjeLiczniki(lekarze);
        return znajdzNajpopularniejszeSpecjalizacjeZLicznikami(specjalizacjeLiczniki);
    }

    public static List<Lekarz> znajdzTopNNajstarszychLekarzy(List<Lekarz> lekarze, int n) {
        List<Lekarz> najstarsiLekarze = new ArrayList<>(lekarze);
        najstarsiLekarze.sort(Comparator.comparing(Lekarz::getDataUrodzenia));
        return najstarsiLekarze.subList(0, Math.min(n, najstarsiLekarze.size()));
    }

    public static List<Lekarz> znajdzLekarzyExclusive(List<Wizyta> wizyty) {
        Map<Lekarz, Set<Pacjent>> lekarzPacjenciMapa = utworzMapeLekarzPacjenci(wizyty);
        return znajdzLekarzyExclusiveZMapy(lekarzPacjenciMapa);
    }

    private static Map<Lekarz, Set<Pacjent>> utworzMapeLekarzPacjenci(List<Wizyta> wizyty) {
        Map<Lekarz, Set<Pacjent>> lekarzPacjenciMapa = new HashMap<>();
        for (Wizyta wizyta : wizyty) {
            Lekarz lekarz = wizyta.getLekarz();
            Pacjent pacjent = wizyta.getPacjent();
            lekarzPacjenciMapa.computeIfAbsent(lekarz, k -> new HashSet<>()).add(pacjent);
        }
        return lekarzPacjenciMapa;
    }

    private static List<Lekarz> znajdzLekarzyExclusiveZMapy(Map<Lekarz, Set<Pacjent>> lekarzPacjenciMapa) {
        List<Lekarz> lekarzeExclusive = new ArrayList<>();
        for (Map.Entry<Lekarz, Set<Pacjent>> entry : lekarzPacjenciMapa.entrySet()) {
            if (entry.getValue().size() == 1) {
                lekarzeExclusive.add(entry.getKey());
            }
        }
        return lekarzeExclusive;
    }

    private static int znajdzMaxLiczbaWizyt(List<Lekarz> lekarze) {
        int maxLiczbaWizyt = 0;
        for (Lekarz lekarz : lekarze) {
            int liczbaWizyt = lekarz.getWizyty().size();
            if (liczbaWizyt > maxLiczbaWizyt) {
                maxLiczbaWizyt = liczbaWizyt;
            }
        }
        return maxLiczbaWizyt;
    }

    private static void dodajLekarzyZNajwiekszaLiczbaWizyt(List<Lekarz> lekarze, List<Lekarz> lekarzeZNajwiecejWizyt, int maxLiczbaWizyt) {
        for (Lekarz lekarz : lekarze) {
            int liczbaWizyt = lekarz.getWizyty().size();
            if (liczbaWizyt == maxLiczbaWizyt) {
                lekarzeZNajwiecejWizyt.add(lekarz);
            }
        }
    }

    private static Map<String, Integer> obliczSpecjalizacjeLiczniki(List<Lekarz> lekarze) {
        Map<String, Integer> specjalizacjeLiczniki = new HashMap<>();
        for (Lekarz lekarz : lekarze) {
            String specjalizacja = lekarz.getSpecjalnosc();
            specjalizacjeLiczniki.put(specjalizacja, specjalizacjeLiczniki.getOrDefault(specjalizacja, 0) + 1);
        }
        return specjalizacjeLiczniki;
    }

    private static List<String> znajdzNajpopularniejszeSpecjalizacjeZLicznikami(Map<String, Integer> specjalizacjeLiczniki) {
        List<String> najpopularniejszeSpecjalizacje = new ArrayList<>();
        int maxLicznik = znajdzMaxLicznik(specjalizacjeLiczniki);
        dodajNajpopularniejszeSpecjalizacje(specjalizacjeLiczniki, najpopularniejszeSpecjalizacje, maxLicznik);
        return najpopularniejszeSpecjalizacje;
    }

    private static int znajdzMaxLicznik(Map<String, Integer> specjalizacjeLiczniki) {
        int maxLicznik = -1;
        for (int licznik : specjalizacjeLiczniki.values()) {
            if (licznik > maxLicznik) {
                maxLicznik = licznik;
            }
        }
        return maxLicznik;
    }

    private static void dodajNajpopularniejszeSpecjalizacje(Map<String, Integer> specjalizacjeLiczniki, List<String> najpopularniejszeSpecjalizacje, int maxLicznik) {
        for (Map.Entry<String, Integer> entry : specjalizacjeLiczniki.entrySet()) {
            if (entry.getValue() == maxLicznik) {
                najpopularniejszeSpecjalizacje.add(entry.getKey());
            }
        }
    }


    public int getIdentyfikator() {
        return identyfikator;
    }

    public String getNazwisko() {
        return nazwisko;
    }

    public String getImie() {
        return imie;
    }

    public String getSpecjalnosc() {
        return specjalnosc;
    }

    public LocalDate getDataUrodzenia() {
        return dataUrodzenia;
    }

    public String getNip() {
        return nip;
    }

    public String getPesel() {
        return pesel;
    }

    public List<Wizyta> getWizyty() {
        return wizyty;
    }

    @Override
    public String toString() {
        return "Lekarz{" +
                "identyfikator=" + identyfikator +
                ", nazwisko='" + nazwisko + '\'' +
                ", imie='" + imie + '\'' +
                ", specjalnosc='" + specjalnosc + '\'' +
                ", dataUrodzenia=" + dataUrodzenia +
                ", nip='" + nip + '\'' +
                ", pesel='" + pesel + '\'' +
                '}';
    }
}
