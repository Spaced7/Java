import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {

        List<Lekarz> lekarze = wczytajLekarzyZPliku("lekarze.txt");
        List<Pacjent> pacjenci = wczytajPacjentowZPliku("pacjenci.txt");
        List<Wizyta> wizyty = wczytajWizytyZPliku("wizyty.txt", lekarze, pacjenci);



        System.out.println(Pacjent.znajdzPacjentowZNajwiekszaLiczbaWizyt(pacjenci));
        System.out.println(Lekarz.znajdzLekarzyZNajwiekszaLiczbaWizyt(lekarze));
        System.out.println(Lekarz.znajdzNajpopularniejszeSpecjalizacje(lekarze));
        System.out.println(Wizyta.znajdzRokZNajwiekszaLiczbaWizyt(wizyty));
        System.out.println(Lekarz.znajdzTopNNajstarszychLekarzy(lekarze, 5));
        System.out.println(Pacjent.znajdzPacjentowZMinNRoznymiLekarzami(wizyty, 5));
        System.out.println(Lekarz.znajdzLekarzyExclusive(wizyty));

    }

    public static List<Lekarz> wczytajLekarzyZPliku(String nazwaPliku) {
        List<Lekarz> lekarze = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(nazwaPliku))) {
            String linia;
            reader.readLine();
            while ((linia = reader.readLine()) != null) {
                String[] wycinek = linia.split("\t");
                int identyfikator = Integer.parseInt(wycinek[0]);
                String nazwisko = wycinek[1];
                String imie = wycinek[2];
                String specjalnosc = wycinek[3];
                LocalDate dataUrodzenia = LocalDate.parse(wycinek[4]);
                String nip = wycinek[5];
                String pesel = wycinek[6];
                lekarze.add(new Lekarz(identyfikator, nazwisko, imie, specjalnosc, dataUrodzenia, nip, pesel));
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return lekarze;
    }

    public static List<Pacjent> wczytajPacjentowZPliku(String nazwaPliku) {
        List<Pacjent> pacjenci = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(nazwaPliku))) {
            String linia;
            reader.readLine();
            while ((linia = reader.readLine()) != null) {
                String[] wycinek = linia.split("\t");
                int identyfikator = Integer.parseInt(wycinek[0]);
                String nazwisko = wycinek[1];
                String imie = wycinek[2];
                String pesel = wycinek[3];
                String poprawnaData = poprawnyFormatDaty(wycinek[4]);
                LocalDate dataUrodzenia = LocalDate.parse(poprawnaData);
                pacjenci.add(new Pacjent(identyfikator, nazwisko, imie, pesel, dataUrodzenia));
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return pacjenci;
    }

    public static List<Wizyta> wczytajWizytyZPliku(String nazwaPliku, List<Lekarz> lekarze, List<Pacjent> pacjenci) {
        List<Wizyta> wizyty = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(nazwaPliku))) {
            String linia;
            reader.readLine();
            while ((linia = reader.readLine()) != null) {
                String[] wycinek = linia.split("\t");
                int lekarzId = Integer.parseInt(wycinek[0]);
                int pacjentId = Integer.parseInt(wycinek[1]);
                String poprawnaData = poprawnyFormatDaty(wycinek[2]);
                LocalDate data = LocalDate.parse(poprawnaData);
                Lekarz lekarz = znajdzLekarzaPoId(lekarze, lekarzId);
                Pacjent pacjent = znajdzPacjentaPoId(pacjenci, pacjentId);
                if (lekarz != null && pacjent != null) {
                    wizyty.add(new Wizyta(lekarz, pacjent, data));
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return wizyty;
    }

    private static Lekarz znajdzLekarzaPoId(List<Lekarz> lekarze, int identyfikator) {
        for (Lekarz lekarz : lekarze) {
            if (lekarz.getIdentyfikator() == identyfikator) {
                return lekarz;
            }
        }
        return null;
    }

    private static Pacjent znajdzPacjentaPoId(List<Pacjent> pacjenci, int identyfikator) {
        for (Pacjent pacjent : pacjenci) {
            if (pacjent.getIdentyfikator() == identyfikator) {
                return pacjent;
            }
        }
        return null;
    }

    private static String poprawnyFormatDaty(String data) {
        String[] dataParts = data.split("-");
        String rok = dataParts[0];
        String miesiac = dataParts[1].length() == 1 ? "0" + dataParts[1] : dataParts[1];
        String dzien = dataParts[2].length() == 1 ? "0" + dataParts[2] : dataParts[2];
        return rok + "-" + miesiac + "-" + dzien;
    }

}
