import java.time.LocalDate;
import java.util.*;
import java.util.List;

public class Pacjent {
    private int identyfikator;
    private String nazwisko;
    private String imie;
    private String pesel;
    private LocalDate dataUrodzenia;
    private List<Wizyta> wizyty = new ArrayList<>();

    public Pacjent(int identyfikator, String nazwisko, String imie, String pesel, LocalDate dataUrodzenia) {
        this.identyfikator = identyfikator;
        this.nazwisko = nazwisko;
        this.imie = imie;
        this.pesel = pesel;
        this.dataUrodzenia = dataUrodzenia;
    }

    public static List<Pacjent> znajdzPacjentowZNajwiekszaLiczbaWizyt(List<Pacjent> pacjenci) {
        List<Pacjent> pacjenciZNajwiecejWizyt = new ArrayList<>();
        int maxLiczbaWizyt = 0;
        for (Pacjent pacjent : pacjenci) {
            int liczbaWizyt = pacjent.getWizyty().size();
            if (liczbaWizyt > maxLiczbaWizyt) {
                maxLiczbaWizyt = liczbaWizyt;
                pacjenciZNajwiecejWizyt.clear();
                pacjenciZNajwiecejWizyt.add(pacjent);
            } else if (liczbaWizyt == maxLiczbaWizyt) {
                pacjenciZNajwiecejWizyt.add(pacjent);
            }
        }
        return pacjenciZNajwiecejWizyt;
    }

    public static List<Pacjent> znajdzPacjentowZMinNRoznymiLekarzami(List<Wizyta> wizyty, int n) {
        Map<Pacjent, Set<Lekarz>> pacjentLekarzeMap = utworzMapePacjentLekarze(wizyty);
        return znajdzPacjentowZMinNRoznymiLekarzamiZMapy(pacjentLekarzeMap, n);
    }

    private static Map<Pacjent, Set<Lekarz>> utworzMapePacjentLekarze(List<Wizyta> wizyty) {
        Map<Pacjent, Set<Lekarz>> pacjentLekarzeMapa = new HashMap<>();
        for (Wizyta wizyta : wizyty) {
            Pacjent pacjent = wizyta.getPacjent();
            Lekarz lekarz = wizyta.getLekarz();
            pacjentLekarzeMapa.computeIfAbsent(pacjent, k -> new HashSet<>()).add(lekarz);
        }
        return pacjentLekarzeMapa;
    }

    private static List<Pacjent> znajdzPacjentowZMinNRoznymiLekarzamiZMapy(Map<Pacjent, Set<Lekarz>> pacjentLekarzeMap, int n) {
        List<Pacjent> pacjenciZMinNRoznymiLekarzami = new ArrayList<>();
        for (Map.Entry<Pacjent, Set<Lekarz>> entry : pacjentLekarzeMap.entrySet()) {
            if (entry.getValue().size() >= n) {
                pacjenciZMinNRoznymiLekarzami.add(entry.getKey());
            }
        }
        return pacjenciZMinNRoznymiLekarzami;
    }

    public int getIdentyfikator() {
        return identyfikator;
    }

    public String getNazwisko() {
        return nazwisko;
    }

    public String getImie() {
        return imie;
    }

    public String getPesel() {
        return pesel;
    }

    public LocalDate getDataUrodzenia() {
        return dataUrodzenia;
    }

    public List<Wizyta> getWizyty() {
        return wizyty;
    }

    @Override
    public String toString() {
        return "Pacjent{" +
                "identyfikator=" + identyfikator +
                ", nazwisko='" + nazwisko + '\'' +
                ", imie='" + imie + '\'' +
                ", pesel='" + pesel + '\'' +
                ", dataUrodzenia=" + dataUrodzenia +
                '}';
    }
}
