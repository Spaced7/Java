import java.time.Instant;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Wizyta {
    private Lekarz lekarz;
    private Pacjent pacjent;
    private LocalDate data;

    public Wizyta(Lekarz lekarz, Pacjent pacjent, LocalDate data) {
        if (pacjent == null) {
            throw new EntityNotFoundException(Instant.now(), "pacjent", "identyfikator");
        }
        if (lekarz == null) {
            throw new EntityNotFoundException(Instant.now(), "lakarz", "identyfikator");
        }
        this.lekarz = lekarz;
        this.pacjent = pacjent;
        this.data = data;

        lekarz.getWizyty().add(this);
        pacjent.getWizyty().add(this);
    }


    public static List<Integer> znajdzRokZNajwiekszaLiczbaWizyt(List<Wizyta> wizyty) {
        Map<Integer, Integer> rokZliczenia = zliczWizytyLata(wizyty);
        return znajdzLataZNajwiekszaLiczbaWizyt(rokZliczenia);
    }

    private static Map<Integer, Integer> zliczWizytyLata(List<Wizyta> wizyty) {
        Map<Integer, Integer> rokZliczenia = new HashMap<>();
        for (Wizyta wizyta : wizyty) {
            int rok = wizyta.getData().getYear();
            rokZliczenia.put(rok, rokZliczenia.getOrDefault(rok, 0) + 1);
        }
        return rokZliczenia;
    }

    private static List<Integer> znajdzLataZNajwiekszaLiczbaWizyt(Map<Integer, Integer> rokZliczenia) {
        List<Integer> lataNajwiecejWizyt = new ArrayList<>();
        int maxLiczbaWizyt = -1;
        for (Map.Entry<Integer, Integer> entry : rokZliczenia.entrySet()) {
            int liczbaWizyt = entry.getValue();
            if (liczbaWizyt > maxLiczbaWizyt) {
                maxLiczbaWizyt = liczbaWizyt;
                lataNajwiecejWizyt.clear();
                lataNajwiecejWizyt.add(entry.getKey());
            } else if (liczbaWizyt == maxLiczbaWizyt) {
                lataNajwiecejWizyt.add(entry.getKey());
            }
        }
        return lataNajwiecejWizyt;
    }

    public Lekarz getLekarz() {
        return lekarz;
    }

    public Pacjent getPacjent() {
        return pacjent;
    }

    public LocalDate getData() {
        return data;
    }


    @Override
    public String toString() {
        return "Wizyta{" +
                "lekarz=" + lekarz.getIdentyfikator() +
                ", pacjent=" + pacjent.getIdentyfikator() +
                ", data=" + data +
                '}';
    }
}
