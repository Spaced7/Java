package pl.test3.zadanie2;

public class DuplicatedElementOnListException extends RuntimeException {
    public DuplicatedElementOnListException(String message) {
        super(message);
    }
}
