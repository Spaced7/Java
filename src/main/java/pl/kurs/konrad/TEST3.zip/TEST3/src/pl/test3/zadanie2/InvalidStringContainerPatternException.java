package pl.test3.zadanie2;

public class InvalidStringContainerPatternException extends RuntimeException {
    public InvalidStringContainerPatternException(String message) {
        super(message);
    }
}
