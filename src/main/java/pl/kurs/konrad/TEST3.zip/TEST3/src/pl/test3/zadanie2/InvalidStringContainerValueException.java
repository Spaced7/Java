package pl.test3.zadanie2;

public class InvalidStringContainerValueException extends RuntimeException {
    public InvalidStringContainerValueException(String message) {
        super(message);
    }
}
