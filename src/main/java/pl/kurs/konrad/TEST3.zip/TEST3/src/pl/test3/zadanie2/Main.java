package pl.test3.zadanie2;

import java.time.LocalDateTime;

public class Main {
    public static void main(String[] args) {

        StringContainer st = new StringContainer("\\d{2}[-]\\d{3}", true);
        st.add("02-495");
        st.add("01-120");
        st.add("05-123");
        st.add("00-000");


        for (int i = 0; i < st.size(); i++) {
            System.out.println(st.get(i));
        }

        st.remove(0);
        st.remove("00-000");

        System.out.println("po usunieciu");

        for (int i = 0; i < st.size(); i++) {
            System.out.println(st.get(i));

        }

        LocalDateTime dateFrom = LocalDateTime.parse("2023-08-08T00:00:00");
        LocalDateTime dateTo = LocalDateTime.parse("2023-08-08T00:17:00");

        StringContainer stBetween = st.getDataBetween(dateFrom, dateTo);

        System.out.println("elementy dodane pomiedzy " + dateFrom + ", a " + dateTo + " to: ");

        for (int i = 0; i < stBetween.size(); i++) {
            System.out.println(stBetween.get(i));
        }
    }
}
