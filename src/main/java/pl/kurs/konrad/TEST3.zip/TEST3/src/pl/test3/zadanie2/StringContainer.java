package pl.test3.zadanie2;

import java.time.LocalDateTime;
import java.util.regex.PatternSyntaxException;

public class StringContainer {
    private Node<String> head;
    private String pattern;
    private boolean duplicatedNotAllowed;


    public StringContainer(String pattern, boolean duplicatedNotAllowed) {
        if (!isValidPattern(pattern)) {
            throw new InvalidStringContainerPatternException(pattern);
        }
        this.pattern = pattern;
        this.duplicatedNotAllowed = duplicatedNotAllowed;
    }


    public void add(String value) {
        validatePattern(value);
        validateDuplicates(value);

        Node<String> newNode = new Node<>(value, null);
        if (head == null) {
            head = newNode;
        } else {
            Node<String> lastNode = findLastNode();
            lastNode.setNext(newNode);
        }
    }

    public String get(int index) {
        validateIndex(index);
        Node<String> node = findNodeAtIndex(index);
        return node.getValue();
    }

    public void remove(int index) {
        validateIndex(index);
        if (index == 0) {
            removeFirstNode();
            return;
        }
        removeNodeAtIndex(index);
    }

    public void remove(String value) {
        if (head == null) {
            return;
        }
        if (head.getValue().equals(value)) {
            removeFirstNode();
            return;
        }
        removeNodeWithValue(value);
    }

    public int size() {
        int count = 0;
        Node<String> current = head;
        while (current != null) {
            count++;
            current = current.getNext();
        }
        return count;
    }

    public StringContainer getDataBetween(LocalDateTime dateFrom, LocalDateTime dateTo) {
        StringContainer result = new StringContainer(pattern, duplicatedNotAllowed);
        Node<String> current = head;
        while (current != null) {
            LocalDateTime addedDate = current.getAddedDate();
            if ((dateFrom == null || addedDate.isAfter(dateFrom) || addedDate.isEqual(dateFrom))
                    && (dateTo == null || addedDate.isBefore(dateTo) || addedDate.isEqual(dateTo))) {
                result.add(current.getValue());
            }
            current = current.getNext();
        }
        return result;
    }



    private void validatePattern(String value) {
        if (!value.matches(pattern)) {
            throw new InvalidStringContainerValueException(value);
        }
    }

    private void validateDuplicates(String value) {
        if (duplicatedNotAllowed && contains(value)) {
            throw new DuplicatedElementOnListException(value);
        }
    }

    private Node<String> findLastNode() {
        Node<String> current = head;
        while (current.getNext() != null) {
            current = current.getNext();
        }
        return current;
    }

    private void validateIndex(int index) {
        if (index < 0) {
            throw new IndexOutOfBoundsException(index);
        }
    }

    private Node<String> findNodeAtIndex(int index) {
        Node<String> current = head;
        int count = 0;
        while (current != null) {
            if (count == index) {
                return current;
            }
            count++;
            current = current.getNext();
        }
        throw new IndexOutOfBoundsException(index);
    }


    private void removeFirstNode() {
        head = head.getNext();
    }

    private void removeNodeAtIndex(int index) {
        Node<String> previous = findNodeAtIndex(index - 1);
        Node<String> current = previous.getNext();
        previous.setNext(current.getNext());
    }


    private void removeNodeWithValue(String value) {
        Node<String> previous = findNodeWithPrevious(value);
        if (previous != null) {
            Node<String> current = previous.getNext();
            previous.setNext(current.getNext());
        }
    }

    private Node<String> findNodeWithPrevious(String value) {
        Node<String> current = head;
        while (current.getNext() != null) {
            if (current.getNext().getValue().equals(value)) {
                return current;
            }
            current = current.getNext();
        }
        return null;
    }

    private boolean contains(String value) {
        Node<String> current = head;
        while (current != null) {
            if (current.getValue().equals(value)) {
                return true;
            }
            current = current.getNext();
        }
        return false;
    }

    private boolean isValidPattern(String pattern) {
        try {
            "".matches(pattern);
            return true;
        } catch (PatternSyntaxException e) {
            return false;
        }
    }

    @Override
    public String toString() {
        return "StringContainer{" +
                "head=" + head +
                ", pattern='" + pattern + '\'' +
                ", duplicatedNotAllowed=" + duplicatedNotAllowed +
                '}';
    }

    static class Node<T> {
        private T value;
        private Node<T> next;
        private LocalDateTime addedDate;

        public Node(T value, Node<T> next) {
            this.value = value;
            this.next = next;
            this.addedDate = LocalDateTime.now();
        }

        public T getValue() {
            return value;
        }

        public Node<T> getNext() {
            return next;
        }

        public void setNext(Node<T> next) {
            this.next = next;
        }

        public LocalDateTime getAddedDate() {
            return addedDate;
        }

        @Override
        public String toString() {
            return "Node{" +
                    "value=" + value +
                    ", addedDate=" + addedDate +
                    '}';
        }
    }
}

